# riva-client
Riva-Client deployed as a python flask service using redis as celery message broker.
